# Development

Go to <https://github.com/Manevle16/epics-team-builder-web-app/tree/master/epics-team-builder> for readme
